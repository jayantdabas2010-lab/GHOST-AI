import requests
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    MessageHandler,
    ContextTypes,
    filters,
)

TELEGRAM_TOKEN = "8794213447:AAGDGtY0cWWdzOZGnK3cC4uGA2T5tsPKjuo"
GROQ_API_KEY = "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"

API_URL = "https://api.groq.com/openai/v1/chat/completions"

MODEL = "llama-3.3-70b-versatile"

SYSTEM_PROMPT = """
You are an advanced AI assistant.
Be smart, helpful, accurate, and creative.
Help users with coding, writing, learning,
brainstorming, and conversations.
"""

async def chat(update: Update, context: ContextTypes.DEFAULT_TYPE):

    user_message = update.message.text

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": MODEL,
        "messages": [
            {
                "role": "system",
                "content": SYSTEM_PROMPT
            },
            {
                "role": "user",
                "content": user_message
            }
        ],
        "temperature": 0.7,
        "max_tokens": 2048
    }

    try:

        response = requests.post(
            API_URL,
            headers=headers,
            json=data,
            timeout=60
        )

        result = response.json()

        reply = result["choices"][0]["message"]["content"]

        await update.message.reply_text(reply[:4000])

    except Exception as e:

        await update.message.reply_text(
            f"Error: {str(e)}"
        )

def main():

    app = ApplicationBuilder().token(
        TELEGRAM_TOKEN
    ).build()

    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, chat)
    )

    print("Telegram AI Bot Running...")

    app.run_polling()

if __name__ == "__main__":
    main()
